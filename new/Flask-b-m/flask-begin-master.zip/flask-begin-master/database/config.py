"""."""
# Guide: http://docs.mongoengine.org/projects/flask-mongoengine/en/latest/
# Remeber to configure the following
# DB
# host
# port
# username
# password
